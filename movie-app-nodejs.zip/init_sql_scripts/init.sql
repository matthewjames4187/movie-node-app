create table movie_hero (
	movie text,
	hero text
);

insert into movie_hero(movie, hero) values ('Titanic', 'Leonardo DiCaprio');
insert into movie_hero(movie, hero) values ('The GodFather', 'Marlon Brando');
insert into movie_hero(movie, hero) values ('Inception', 'Leonardo DiCaprio');
insert into movie_hero(movie, hero) values ('Russia', 'Moscow');